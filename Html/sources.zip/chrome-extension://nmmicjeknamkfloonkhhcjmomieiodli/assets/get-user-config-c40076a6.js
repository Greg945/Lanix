import{g as t}from"./jsx-runtime-4286988b.js";import{D as e}from"./createLucideIcon-6676f207.js";const a=async()=>{const r=await t(Object.keys(e));return r?{...e,...r}:e};export{a as g};
